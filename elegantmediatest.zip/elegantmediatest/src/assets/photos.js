import greentrees from "./greentrees.jpg";
import heroimg from "./heroimg.jpg";
import onetree from "./onetree.jpg";
import river from "./river.jpg";
import profile01 from "./profileimg01.jpg";
import profile02 from "./profileimg02.jpg";
import profile03 from "./profileimg03.jpg";
import telescope from "./telescope.jpg";
import map from "./map.jpg";

export {
    greentrees,
    heroimg,
    onetree,
    river,
    telescope,
    map,
    profile01,
    profile02,
    profile03,
}