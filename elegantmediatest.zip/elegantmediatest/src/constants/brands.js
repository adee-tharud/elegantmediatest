  export const brands = [
    "RotaShow",
    "Waves",
    "Travelers",
    "RotaShow",
    "Goldlines",
    "Velocity 9",
  ];