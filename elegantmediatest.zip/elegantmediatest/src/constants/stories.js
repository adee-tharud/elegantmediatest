import { profile02, profile03} from "../assets/photos";

export const stories = [
    {
      id: 1,
      image: profile02,
      title: "The Nature",
      date: "22/06/2016",
      subtitle: "More Sustainably",
    },
    {
      id: 2,
      image: profile03,
      title: "Tim Sar",
      date: "16/02/2004",
      subtitle: "You Can Contribute",
    },
  ];
  