import { Leaf, Plus } from "lucide-react"

export const sus =[
    {
        id: 1,
        firstone: "Sustainable Living",
        secondone: "Messages Nature",
        image: Leaf,
    },
    {
        id: 2,
        firstone: "Deep Exploration",
        secondone: "Of Nature",
        image: Plus,
    }
]